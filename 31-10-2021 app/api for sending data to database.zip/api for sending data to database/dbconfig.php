<?php
/****************************************************/
/************** Created by : Vivek Gupta ************/
/***************     www.vsgupta.in     *************/
/***************     www.iotmonk.com     *************/
/****************************************************/ 
define('DB_USER', "tecozk_agritech");     // Your database user name
define('DB_PASSWORD', "dbase_fc");			// Your database password (mention your db password here)
define('DB_DATABASE', "tecozk_tecozk_agritech1"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)
?>